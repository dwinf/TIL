from django.apps import AppConfig


class WorkappConfig(AppConfig):
    name = 'workapp'
