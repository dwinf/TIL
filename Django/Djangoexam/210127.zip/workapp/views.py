from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader


def exercise1(request):
    template = loader.get_template('exercise1.html')
    msg = "kdc"
    context = {'result': msg}
    return HttpResponse(template.render(context, request))

# Create your views here.
